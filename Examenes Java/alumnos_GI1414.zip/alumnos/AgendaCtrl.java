import java.awt.event.*;
import java.util.*;

public class AgendaCtrl implements ActionListener 
{

	private AgendaVista vista;
	private Agenda modelo;
	private Contacto c;
	
	public AgendaCtrl(AgendaVista vista, Agenda modelo)
	{

	}
	
	public void actionPerformed(ActionEvent e)
	{
		String comando = e.getActionCommand();
		
		if(comando.equals(AgendaVista.BORRA))
		{

			vista.mensaje("Se ha borrado el contacto");				
		}
		else if(comando.equals(AgendaVista.BUSCA))
		{

		}
		else if(comando.equals(AgendaVista.RESETEA))
		{

		}
		if(comando.equals(AgendaVista.ANADE))
		{

		}

	}
}
