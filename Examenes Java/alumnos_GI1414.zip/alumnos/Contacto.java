import java.util.*;

public class Contacto implements Comparable<Contacto> 
{
	private String nombre;
	private String apellido;
	private String email;
	private String telefono;
	
	public static List<Contacto> ListaContactos()
	{

	}
	public Contacto(String n, String a, String e, String t)
	{

	}
	
	public Contacto(String t)
	{

	}
	
	public String getValor(Campo campo)
	{

	}
	
	public void setValor(Campo campo, String valor)
	{

	}
	
	public void borraContacto()
	{

	}
	

	public String toString()
	{

	}
	
	public boolean equals(Object o)
	{
		return (o instanceof Contacto)
				&& this.getValor(Campo.NOMBRE).equalsIgnoreCase(((Contacto) o).getValor(Campo.NOMBRE))
				&& this.getValor(Campo.APELLIDO).equalsIgnoreCase(((Contacto) o).getValor(Campo.APELLIDO))
				&& this.getValor(Campo.TELEFONO).equalsIgnoreCase(((Contacto) o).getValor(Campo.TELEFONO))
				&& this.getValor(Campo.EMAIL).equalsIgnoreCase(((Contacto) o).getValor(Campo.EMAIL));
	}


	public int compareTo(Contacto c)
	{
		int res = this.getValor(Campo.NOMBRE).compareTo(c.getValor(Campo.NOMBRE));
		if (res==0)
			res = this.getValor(Campo.APELLIDO).compareTo(c.getValor(Campo.APELLIDO));
		if (res==0)
			res = this.getValor(Campo.TELEFONO).compareTo(c.getValor(Campo.TELEFONO));
		if (res==0)
			res = this.getValor(Campo.EMAIL).compareTo(c.getValor(Campo.EMAIL));
		return res;
	}
	

}
