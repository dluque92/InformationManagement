import java.io.*;
import java.util.*;

public class Agenda 
{
	public Agenda()
	{
	}
	
	public Agenda(String file)
	{
		leerFichero(file);
	}
	
	public void leerFichero(String file)
	{
		if (file==null)
			throw new Error("ERROR: Argumento no v�lido");
		
		try
		{
			BufferedReader bfr = new BufferedReader(new FileReader(file));
			leerFichero(bfr);
			bfr.close();
		}
		catch (IOException e)
		{
			throw new Error("ERROR al tratar el fichero");
		}
		
	}
	private void leerFichero(BufferedReader bfr)
	{		
		try
		{
			String linea;
			linea = bfr.readLine();

			while(linea!=null)
			{				
				StringTokenizer st = new StringTokenizer(linea,",#");
				
				String apellido = st.nextToken();
				String nombre = st.nextToken();
				String telefono = st.nextToken();
				String email = st.nextToken();
				
				try
				{
					Contacto c = new Contacto(nombre,apellido,email,telefono);
				}
				catch (Error err) 
				{ //Ignoro el error por insercciones repetidas
				}
				linea = bfr.readLine();	
			}						
		}
		catch(NoSuchElementException e)
		{
			throw new Error("ERROR al encontrar elemento");
		}
		catch (IOException e) 
		{
			throw new Error("ERROR al tratar fichero");
		}
	}

	public String toString()
	{
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);		
		for(Contacto c: Contacto.ListaContactos()) pw.println(c.toString());
		String s =sw.getBuffer().toString(); 
		pw.close();
		return s;
	}
}
