
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import java.util.HashMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

public class AgendaPanel extends JPanel implements AgendaVista 
{
	private Map<Campo, JTextField> jtfs;
	private JButton bBorra, bBusca, bAnade, bResetea;
	private JTextArea aTexto;
	private JLabel mensaje;

	public AgendaPanel() 
	{
		jtfs = new HashMap<Campo, JTextField>();
		jtfs.put(Campo.APELLIDO, new JTextField());
		jtfs.put(Campo.NOMBRE, new JTextField());
		jtfs.put(Campo.TELEFONO, new JTextField());
		jtfs.put(Campo.EMAIL, new JTextField());
		bBorra = new JButton("BORRA");
		bBusca = new JButton("BUSCA");
		bAnade = new JButton("A�ADE");
		bResetea = new JButton("RESETEA");
		aTexto = new JTextArea(8, 20);
		aTexto.setEditable(false);

		JPanel botonera = new JPanel();
		botonera.setLayout(new GridLayout(4, 3, 10, 10));
		JLabel lApellido = new JLabel("Apellido");
		lApellido.setHorizontalAlignment(SwingConstants.CENTER);
		botonera.add(lApellido);
		botonera.add(jtfs.get(Campo.APELLIDO));
		botonera.add(bBorra);
		JLabel lNombre = new JLabel("Nombre");
		lNombre.setHorizontalAlignment(SwingConstants.CENTER);
		botonera.add(lNombre);
		botonera.add(jtfs.get(Campo.NOMBRE));
		botonera.add(bBusca);
		JLabel lTelefono = new JLabel("Tel�fono");
		lTelefono.setHorizontalAlignment(SwingConstants.CENTER);
		botonera.add(lTelefono);
		botonera.add(jtfs.get(Campo.TELEFONO));
		botonera.add(bAnade);
		JLabel lEmail = new JLabel("E-mail");
		lEmail.setHorizontalAlignment(SwingConstants.CENTER);
		botonera.add(lEmail);
		botonera.add(jtfs.get(Campo.EMAIL));
		botonera.add(bResetea);
		
		mensaje = new JLabel("Agenda creada");
		mensaje.setBorder(BorderFactory.createEtchedBorder());

		JPanel sur = new JPanel();
		sur.setLayout(new BorderLayout());
		sur.add(BorderLayout.CENTER, botonera);
		sur.add(BorderLayout.SOUTH, mensaje);

		setLayout(new GridLayout(2, 1));
		add(aTexto);
		add(sur);
	}

	@Override
	public void controlador(ActionListener ctrl) 
	{
		bBorra.addActionListener(ctrl);
		bBorra.setActionCommand(AgendaVista.BORRA);
		bBusca.addActionListener(ctrl);
		bBusca.setActionCommand(AgendaVista.BUSCA);
		bAnade.addActionListener(ctrl);
		bAnade.setActionCommand(AgendaVista.ANADE);
		bResetea.addActionListener(ctrl);
		bResetea.setActionCommand(AgendaVista.RESETEA);
	}

	@Override
	public void borraContacto() 
	{
		for (Campo c : jtfs.keySet()) {
			jtfs.get(c).setText("");
		}
	}

	@Override
	public void muestraContacto(Contacto cn) {
		for (Campo cm : jtfs.keySet()) {
			String text="";
			if (cn!=null) text=cn.getValor(cm);
			jtfs.get(cm).setText(text);
		}
	}

	@Override
	public void muestraContactos(String t) {
		aTexto.setText(t);
	}

	@Override
	public Map<Campo, String> leeDatos() {
		Map<Campo, String> m = new HashMap<Campo, String>();
		for (Campo cm : Campo.values()) {
			m.put(cm, jtfs.get(cm).getText());
		}
		return m;
	}

	@Override
	public void mensaje(String texto) {
		mensaje.setText(texto);
	}

}
