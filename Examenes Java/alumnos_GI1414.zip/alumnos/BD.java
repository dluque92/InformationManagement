
import java.sql.*;
import com.microsoft.sqlserver.jdbc.*;
import java.util.*;

public class BD 
{
	private SQLServerDataSource ds;
	private Connection con ;
	private Statement stmt;
	
	public BD(String server, String databaseName)
	{

	}
	
	protected void finalize () 
	{

    	}
	
	public Object SelectEscalar(String sel)
	{

	}
	
	public List<Object[]> Select(String sel)
	{

	}
	
	public void Insert(String ins)
	{

	}

	public void Delete(String del)
	{

	}

	public void Update(String up)
	{

	}

}
