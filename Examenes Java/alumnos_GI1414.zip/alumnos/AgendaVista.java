import java.awt.event.ActionListener;
import java.util.Map;

public interface AgendaVista {
	String BORRA = "Borra", BUSCA = "Busca", RESETEA = "Resetea",
			ANADE = "anade";

	// Borra el contacto mostrado en los campos de texto
	void borraContacto();

	// muestra el contacto c en los campos de texto correspondientes
	void muestraContacto(Contacto c);

	// Pone el string recibido en el �rea de texto de la GUI
	void muestraContactos(String t);

	// Establece el objeto ctrl como oyente de las acciones de la GUI
	void controlador(ActionListener ctrl);

	// Devuelve los datos introducidos en los campos de texto. El map devuelto
	// asocia a cada campo la entrada disponible.
	Map<Campo, String> leeDatos();
	
	// Muestra un mensaje informativo
	void mensaje(String texto);
}
