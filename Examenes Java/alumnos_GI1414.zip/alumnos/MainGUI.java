import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainGUI {
	public static void main(String[] args) 
	{
			Agenda agenda;
			if (args.length == 1) 
			{
				agenda = new Agenda(args[0]);
			}
			else
			{
				agenda = new Agenda();
			}
			
			AgendaVista vista = new AgendaPanel();
			ActionListener ctrl = new AgendaCtrl(vista, agenda);
			vista.controlador(ctrl);

			JFrame gui = new JFrame("MiniAgenda");
			gui.setContentPane((JPanel) vista);
			gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			gui.pack();
			gui.setVisible(true);

	}
}
