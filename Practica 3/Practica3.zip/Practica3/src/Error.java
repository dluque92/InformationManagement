
public class Error extends RuntimeException  
{

	public Error() 
	{
		super();
	}

	public Error(String arg0) 
	{
		super(arg0);
	}
}
